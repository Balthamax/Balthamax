import { Actor } from 'apify';
import { PlaywrightCrawler, sleep } from 'crawlee';

await Actor.init();

const input = await Actor.getInput() ?? {};
const TODAY = new Date().toISOString().split('T')[0];

// ─── Credentials depuis env vars ───────────────────────────────────────────
const CFNEWS_EMAIL    = process.env.CFNEWS_EMAIL    ?? input.cfnews_email;
const CFNEWS_PASSWORD = process.env.CFNEWS_PASSWORD ?? input.cfnews_password;
const LESECHOS_EMAIL    = process.env.LESECHOS_EMAIL    ?? input.lesechos_email;
const LESECHOS_PASSWORD = process.env.LESECHOS_PASSWORD ?? input.lesechos_password;

const results = [];

// ═══════════════════════════════════════════════════════════════════════════
// HELPER : normalise une date en YYYY-MM-DD
// ═══════════════════════════════════════════════════════════════════════════
function parseDate(raw) {
    if (!raw) return null;
    const d = new Date(raw);
    if (!isNaN(d)) return d.toISOString().split('T')[0];
    // format "04/03/2025" ou "4 mars 2025"
    const frMonths = { janvier:0,février:1,mars:2,avril:3,mai:4,juin:5,
                       juillet:6,août:7,septembre:8,octobre:9,novembre:10,décembre:11 };
    const m = raw.match(/(\d{1,2})\s+(\w+)\s+(\d{4})/);
    if (m) {
        const month = frMonths[m[2].toLowerCase()];
        if (month !== undefined) return new Date(+m[3], month, +m[1]).toISOString().split('T')[0];
    }
    return null;
}

// ═══════════════════════════════════════════════════════════════════════════
// 1. CFNEWS
// ═══════════════════════════════════════════════════════════════════════════
const cfnewsCrawler = new PlaywrightCrawler({
    headless: true,
    maxRequestsPerCrawl: 50,

    async requestHandler({ page, request, log }) {

        // ── LOGIN ──────────────────────────────────────────────────────────
        if (request.label === 'LOGIN_CFNEWS') {
            log.info('CFNews : connexion…');
            await page.goto('https://www.cfnews.net/compte/connexion', { waitUntil: 'networkidle' });
            await page.fill('input[name="email"], input[type="email"]', CFNEWS_EMAIL);
            await page.fill('input[name="password"], input[type="password"]', CFNEWS_PASSWORD);
            await Promise.all([
                page.waitForNavigation({ waitUntil: 'networkidle' }),
                page.click('button[type="submit"], input[type="submit"]'),
            ]);
            log.info('CFNews : connecté, scraping liste…');
            await sleep(2000);
            await page.goto('https://www.cfnews.net/Actualite', { waitUntil: 'networkidle' });

            // Collecter les URLs des articles
            const articles = await page.$$eval('article a[href], .article-title a, .news-list a', els =>
                [...new Set(els.map(e => e.href).filter(h => h.includes('/Actualite/') || h.includes('/actualite/')))].slice(0, 30)
            );
            log.info(`CFNews : ${articles.length} articles trouvés`);

            for (const url of articles) {
                await cfnewsCrawler.addRequests([{ url, label: 'ARTICLE_CFNEWS' }]);
                await sleep(2500);
            }
        }

        // ── ARTICLE ────────────────────────────────────────────────────────
        if (request.label === 'ARTICLE_CFNEWS') {
            await page.waitForLoadState('networkidle');
            const titre = await page.$eval(
                'h1, .article-title, .titre-article',
                el => el.innerText.trim()
            ).catch(() => '');

            const dateRaw = await page.$eval(
                'time, .date, .article-date, [class*="date"]',
                el => el.getAttribute('datetime') ?? el.innerText.trim()
            ).catch(() => '');

            const date = parseDate(dateRaw);
            if (date !== TODAY) return; // on garde uniquement aujourd'hui

            const chapeau = await page.$eval(
                '.chapeau, .intro, .article-intro, .summary, p:first-of-type',
                el => el.innerText.trim().slice(0, 400)
            ).catch(() => '');

            const nom_entreprise = await page.$eval(
                '.company-name, .entreprise, [class*="company"], [class*="entreprise"]',
                el => el.innerText.trim()
            ).catch(() => '');

            results.push({ titre, date, chapeau, url_article: request.url, nom_entreprise, source: 'cfnews' });
            log.info(`CFNews ✓ ${titre.slice(0, 60)}`);
        }
    },

    failedRequestHandler({ request, log }) {
        log.error(`CFNews ERREUR : ${request.url}`);
    },
});

await cfnewsCrawler.run([{ url: 'https://www.cfnews.net/compte/connexion', label: 'LOGIN_CFNEWS' }]);


// ═══════════════════════════════════════════════════════════════════════════
// 2. LES ECHOS
// ═══════════════════════════════════════════════════════════════════════════
const echosCrawler = new PlaywrightCrawler({
    headless: true,
    maxRequestsPerCrawl: 50,

    async requestHandler({ page, request, log }) {

        // ── LOGIN ──────────────────────────────────────────────────────────
        if (request.label === 'LOGIN_ECHOS') {
            log.info('Les Echos : connexion…');
            await page.goto('https://www.lesechos.fr/connexion', { waitUntil: 'networkidle' });
            await page.fill('input[name="email"], input[type="email"]', LESECHOS_EMAIL);
            await page.fill('input[name="password"], input[type="password"]', LESECHOS_PASSWORD);
            await Promise.all([
                page.waitForNavigation({ waitUntil: 'networkidle' }),
                page.click('button[type="submit"]'),
            ]);
            log.info('Les Echos : connecté, scraping…');
            await sleep(2000);
            await page.goto('https://www.lesechos.fr/finance-marches/capital-investissement', { waitUntil: 'networkidle' });

            const articles = await page.$$eval('a[href*="/finance-marches/capital-investissement/"]', els =>
                [...new Set(els.map(e => e.href))].filter(h => !h.endsWith('/capital-investissement/')).slice(0, 30)
            );
            log.info(`Les Echos : ${articles.length} articles trouvés`);

            for (const url of articles) {
                await echosCrawler.addRequests([{ url, label: 'ARTICLE_ECHOS' }]);
                await sleep(2500);
            }
        }

        // ── ARTICLE ────────────────────────────────────────────────────────
        if (request.label === 'ARTICLE_ECHOS') {
            await page.waitForLoadState('networkidle');

            const titre = await page.$eval('h1', el => el.innerText.trim()).catch(() => '');

            const dateRaw = await page.$eval(
                'time, [class*="date"], [class*="Date"]',
                el => el.getAttribute('datetime') ?? el.innerText.trim()
            ).catch(() => '');

            const date = parseDate(dateRaw);
            if (date !== TODAY) return;

            const chapeau = await page.$eval(
                '[class*="chapo"], [class*="intro"], [class*="summary"], article p:first-of-type',
                el => el.innerText.trim().slice(0, 400)
            ).catch(() => '');

            const nom_entreprise = await page.$eval(
                '[class*="tag"], [class*="company"], [class*="topic"]',
                el => el.innerText.trim()
            ).catch(() => '');

            results.push({ titre, date, chapeau, url_article: request.url, nom_entreprise, source: 'lesechos' });
            log.info(`Les Echos ✓ ${titre.slice(0, 60)}`);
        }
    },

    failedRequestHandler({ request, log }) {
        log.error(`Les Echos ERREUR : ${request.url}`);
    },
});

await echosCrawler.run([{ url: 'https://www.lesechos.fr/connexion', label: 'LOGIN_ECHOS' }]);


// ═══════════════════════════════════════════════════════════════════════════
// OUTPUT FINAL
// ═══════════════════════════════════════════════════════════════════════════
console.log(`\n✅ Total articles collectés aujourd'hui : ${results.length}`);
console.log(`   CFNews : ${results.filter(r => r.source === 'cfnews').length}`);
console.log(`   Les Echos : ${results.filter(r => r.source === 'lesechos').length}\n`);

await Actor.pushData(results);
await Actor.exit();
