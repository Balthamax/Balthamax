# Veille PE — CFNews + Les Echos

Apify Actor qui scrape les articles du jour sur CFNews et Les Echos.

## Output JSON

```json
[
  {
    "titre": "Ardian lève 3Mds€ pour son nouveau fonds growth",
    "date": "2026-03-04",
    "chapeau": "Le fonds mid-market français finalise...",
    "url_article": "https://www.cfnews.net/...",
    "nom_entreprise": "Ardian",
    "source": "cfnews"
  }
]
```

## Setup sur Apify

1. Va sur https://console.apify.com → "Actors" → "Create new Actor"
2. Upload ce dossier ou connecte ton repo GitHub
3. Dans "Environment variables", ajoute :
   - `CFNEWS_EMAIL` = ton email CFNews
   - `CFNEWS_PASSWORD` = ton mot de passe CFNews (**marquer comme secret**)
   - `LESECHOS_EMAIL` = ton email Les Echos
   - `LESECHOS_PASSWORD` = ton mot de passe Les Echos (**marquer comme secret**)
4. Build l'Actor → "Build"
5. Lance un test → "Start"
6. Vérifie l'onglet "Storage > Dataset" pour voir le JSON en sortie

## Scheduler (cron 7h30)

Dans Apify → ton Actor → "Schedules" → "New schedule"
- Cron expression : `30 7 * * 1-5` (lundi-vendredi à 7h30)

## Notes

- Seuls les articles du jour sont conservés (filtre sur la date)
- Délai de 2.5s entre chaque article (évite le rate limiting)
- Les credentials ne sont jamais dans le code
- Prochaine étape : brancher ce dataset sur n8n pour le scoring Claude
